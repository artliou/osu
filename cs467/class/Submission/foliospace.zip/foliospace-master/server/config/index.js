module.exports = {
    cloudinary:{
        cloud_name: "foliospace", 
        api_key: "986157547172557", 
        api_secret: "LPqmK2cTQAcMSfjhAAAjoqSveR8" 
    },

    mysql:{
        host: "wiad5ra41q8129zn.cbetxkdyhwsb.us-east-1.rds.amazonaws.com",
        user: "wxxl4ykpjxita1zv",
        password: "ntyxgfb9x2dpyr4x",
        database: "nn63dg6ksfqti6ih"        
    }
}