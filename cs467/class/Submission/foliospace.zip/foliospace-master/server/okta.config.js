module.exports = {
    url: "https://dev-613949.okta.com/",
    issuer: 'https://dev-613949.okta.com/oauth2/default',
    client_id: '0oan4do062i9qmclk356',
    client_secret: "wDrQsBa09iRvbaVVh9pfB8ynhdCxUG0DjB89U0RH",
    // redirect_uri: "http://localhost:3000/authorization-code/callback",
    redirect_uri: "http://localhost:3000/users/callback",
    secret: "foliospace",
    token: "008A421hKQLXiXMkm2Uy81DE8LdMJe1W3-fGFcHzgi"
  };