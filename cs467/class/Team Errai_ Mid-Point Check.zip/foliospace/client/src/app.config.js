export default {
  url: 'https://dev-613949.okta.com',
  issuer: 'https://dev-613949.okta.com/oauth2/default',
  redirect_uri: window.location.origin + '/implicit/callback',
  client_id: '0oajlmbbzksJN8t1Z356'
};
