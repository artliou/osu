import React from 'react';

export default () => <h3> AdminPage </h3>;