import React from 'react';

const ListItem = (props) => (
  <div>
    { props.item.description }
  </div>
)

export default ListItem;