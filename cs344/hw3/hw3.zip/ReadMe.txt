"README" that contains instructions on HOW to compile your code; you may compile your code however you wish


To compile, enter the command below
	gcc -g -o smallsh smallsh.c

To run the program, enter the command below
	smallsh