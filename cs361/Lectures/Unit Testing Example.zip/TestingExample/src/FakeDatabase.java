import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/*
 * I sometimes use simple little fake databases like this before I actually set up the structure of the real DB,
 * especially to give teammates some sort of API to use while I work out the details. This one just stores some tools
 * with a certain ID.
 */
public class FakeDatabase {
	protected Map<UUID, String> mIdToTools;
	
	public FakeDatabase() {
		mIdToTools = new HashMap<UUID, String>();
	}
	
	public Map<UUID, String> getIDToToolsMap() {
		return mIdToTools;
	}
	
	public void insertTool(UUID id, String toolName){
		mIdToTools.put(id, toolName);;
	}
	
	protected static String format(String input){
		String formattedString = input.toUpperCase();
		formattedString = "~~~" + formattedString + "~~~\n"; 
		return formattedString.replace("'", "''");
		
	}
}
