import java.util.Map;
import java.util.UUID;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;


public class FakeDatabaseTest {

	private FakeDatabase mFakeDatabase;
	private UUID uuid1;
	private UUID uuid2;
	private Map<UUID, String> map;
	
	//@Before labels a method that gets run before the JUnit tests. In a real app, there will probably be a bit more in this method.
	//You will see @Test below. This indicates methods that should be run as JUnit tests. These are called annotations, and there are a bunch of them.
	@Before
	public void setup() {
		mFakeDatabase = new  FakeDatabase();
		
		map = mFakeDatabase.getIDToToolsMap();
		
		uuid1 = UUID.fromString("88e5138d-162a-480a-a2a2-3ac7dbd4e271");
		mFakeDatabase.insertTool(uuid1, "Little Tiny Hammer");
		
		uuid2 = UUID.fromString("88e5138d-162a-480a-a2a2-3ac7dbd4e272");
		mFakeDatabase.insertTool(uuid2, "Slightly Larger Hammer");
	}
	
	/*
	 * Tests that the "database" has been modified correctly when insert is called. 
	 *	Since I don't have a well-tested interface with this "database", I only rely on something that I know will work (map.contains and map.get)
	 * In a real-world application, I might use a good SQL query to test my methods against. 
	 */
	@Test
	public void testInsertTool() {
		
		Assert.assertTrue(map.containsKey(uuid1) && map.containsKey(uuid2));
		
		String tinyHammerName = map.get(uuid1);
		Assert.assertEquals(tinyHammerName, "Little Tiny Hammer");
	}
	
	/*
	 * Just to show a simple helper method test that, while fairly trivial, might be nice to have during development
	 */
	@Test
	public void testEscapeSingleQuotes(){
		String maybeFormatted = FakeDatabase.format("O'Brian");
		
		// Make sure it comes out in the exact, ugly way that we want it to.
		Assert.assertTrue("~~~O''BRIAN~~~\n".equals(maybeFormatted));
		
	}

	/*
	 * TRIVIAL
	 * This is just a silly test. It is testing a method that ONLY returns the data structure that
	 * I am accessing directly. The only way I could see anybody doing this is as a regression test
	 * to make sure that anybody who modifies FakeDatabase.getIDToToolsMap knows that they are 
	 * violating the expected behavior of the method.
	 */
	@Test
	public void testGetMap(){
		
		for(UUID id : map.keySet()){
			Assert.assertEquals(map.get(id), mFakeDatabase.mIdToTools.get(id));
		}
	}
}
